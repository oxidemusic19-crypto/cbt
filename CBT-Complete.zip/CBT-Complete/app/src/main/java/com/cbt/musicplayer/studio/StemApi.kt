package com.cbt.musicplayer.studio

import android.content.Context
import android.net.Uri
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/** Client for the documented CBT Stem API contract. A real compatible server is required. */
object StemApi {
    fun upload(context: Context, uri: Uri, endpoint: String, apiKey: String): String {
        require(endpoint.startsWith("https://")) { "Use a secure HTTPS API endpoint." }
        val boundary = "CBT-${UUID.randomUUID()}"
        val connection = (URL(endpoint.trimEnd('/') + "/separate").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 30_000
            readTimeout = 300_000
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            if (apiKey.isNotBlank()) setRequestProperty("Authorization", "Bearer $apiKey")
        }
        try {
            val mime = context.contentResolver.getType(uri) ?: "audio/*"
            val name = "audio-${System.currentTimeMillis()}"
            connection.outputStream.use { out ->
                out.write("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"$name\"\r\nContent-Type: $mime\r\n\r\n".toByteArray())
                context.contentResolver.openInputStream(uri)?.use { input -> input.copyTo(out) }
                    ?: error("Could not read selected audio file")
                out.write("\r\n--$boundary--\r\n".toByteArray())
            }
            val code = connection.responseCode
            val body = (if (code in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) error("Server returned HTTP $code: ${body.take(500)}")
            return body
        } finally {
            connection.disconnect()
        }
    }
}
